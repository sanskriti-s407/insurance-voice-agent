# ─── Mock tool response handler — Happy Insurance voice agent ───
# Paste this into the "Mock tool response" editor in Agent Studio.
#
# fake_tool_call() runs BEFORE the real tool.
#   • return a dict  -> agent uses it as the tool's response (no backend call)
#   • return None    -> the real tool is called instead
#
# The real tool name is PREFIXED by the tool/toolset name, e.g. the runtime
# sees "Auth_validateUser", not "validateUser". _op() strips that prefix and
# matches on the action part, so it works no matter what your tools are named.
#
# Remember: the preview Session must be set to use MOCK tool responses,
# not "actual tool responses", or none of this runs.

from typing import Any, Optional


# ── Mock "Firestore": 4 customers keyed by phone number (the document ID) ──
# Each record also carries a security Q/A used as the second auth factor
# (DOB is the first factor on top of the phone number).
CUSTOMERS = {
    "9876543210": {
        "customerId": "C001",
        "name": "Raj Mehta",
        "dob": "1985-04-12",
        "security": {"question": "Which city were you born in?", "answer": "Pune"},
        "policy": {
            "policyId": "POL-MOTOR-001", "type": "Motor", "status": "Active",
            "premium": 14500, "renewalDate": "2026-09-30",
            "vehicle": {"reg": "MH12AB1234", "model": "Honda City"},
        },
        "claims": [
            {"claimId": "CLM-2025-018", "type": "Accident",
             "status": "Settled", "amount": 32000},
        ],
        "benefits": ["Roadside assistance", "Zero depreciation", "Engine protect"],
    },
    "9123456780": {
        "customerId": "C002",
        "name": "Anita Desai",
        "dob": "1990-11-03",
        "security": {"question": "What is your mother's maiden name?", "answer": "Kulkarni"},
        "policy": {
            "policyId": "POL-HEALTH-002", "type": "Health", "status": "Active",
            "premium": 22000, "renewalDate": "2026-12-15",
        },
        "claims": [],
        "benefits": ["Cashless hospitalization", "Annual health checkup", "No-claim bonus"],
    },
    "9988776655": {
        "customerId": "C003",
        "name": "Vikram Rao",
        "dob": "1978-07-22",
        "security": {"question": "Which city were you born in?", "answer": "Bengaluru"},
        "policy": {
            "policyId": "POL-MOTOR-003", "type": "Motor", "status": "Lapsed",
            "premium": 18900, "renewalDate": "2026-05-01",
            "vehicle": {"reg": "KA05CD5678", "model": "Hyundai Creta"},
        },
        "claims": [
            {"claimId": "CLM-2024-091", "type": "Theft",
             "status": "In Review", "amount": 75000},
        ],
        "benefits": ["Roadside assistance", "Personal accident cover"],
    },
    "9001122334": {
        "customerId": "C004",
        "name": "Priya Nair",
        "dob": "1995-02-17",
        "security": {"question": "What is your mother's maiden name?", "answer": "Menon"},
        "policy": {
            "policyId": "POL-LIFE-004", "type": "Life", "status": "Active",
            "premium": 30000, "renewalDate": "2027-01-10",
        },
        "claims": [],
        "benefits": ["Term cover Rs.50L", "Tax benefit 80C", "Accidental death rider"],
    },
}


# ── Product catalogue (paraphrased from the Insurance Product Coverage Guide) ──
# Used by getProductCoverage so the onboarding agents can explain a product
# without needing a Data Store. Structured so the agent can read it out cleanly.
PRODUCTS = {
    "Motor": {
        "summary": "Comprehensive cover for two-wheelers and private cars: own "
                   "damage, theft, third-party liability, and owner-driver "
                   "personal accident cover.",
        "covers": [
            "Own damage (accident, collision, overturning)",
            "Theft of the insured vehicle",
            "Fire, explosion, self-ignition, lightning",
            "Natural calamities (flood, cyclone, earthquake, landslide)",
            "Man-made events (riot, strike, malicious damage, terrorism)",
            "In-transit damage (road, rail, air, waterway)",
            "Third-party property damage and bodily injury/death",
            "Personal accident cover for the owner-driver",
        ],
        "keyLimits": {
            "sumInsured": "Insured Declared Value (market value)",
            "thirdPartyProperty": "Up to Rs 7,50,000",
            "thirdPartyInjuryDeath": "Unlimited (as per law)",
            "ownerDriverPA": "Rs 15,00,000",
            "noClaimBonus": "20% up to 50%",
        },
        "addOns": ["Zero Depreciation", "Roadside Assistance", "Engine Protection",
                   "Return to Invoice", "NCB Protection", "Consumables cover"],
        "exclusions": ["Normal wear, tear and mechanical breakdown",
                       "Driving without a valid licence",
                       "Driving under the influence of alcohol/drugs",
                       "Consequential loss and depreciation (unless add-on)",
                       "Commercial use of a private vehicle",
                       "Damage occurring outside India"],
        "eligibility": "Valid registration (RC) and a roadworthy vehicle.",
        "collect": ["vehicleNumber", "chassisNumber"],
    },
    "Health": {
        "summary": "Hospitalization and medical cover for an individual or the "
                   "whole family under a single floater sum insured, cashless "
                   "or reimbursement.",
        "covers": [
            "In-patient hospitalization (room, ICU, surgery, doctor, nursing)",
            "Pre-hospitalization (60 days) and post-hospitalization (90 days)",
            "Day-care procedures not needing 24-hour admission",
            "Ambulance charges",
            "AYUSH treatment",
            "Domiciliary (at-home) hospitalization",
            "Organ donor expenses",
        ],
        "keyLimits": {
            "sumInsured": "Rs 3L / 5L / 10L / 25L",
            "coverType": "Individual or family floater",
            "prePostHospitalization": "60 days / 90 days",
            "cashlessNetwork": "10,000+ hospitals",
            "taxBenefit": "Section 80D",
        },
        "addOns": ["Maternity and newborn cover", "Critical Illness", "OPD cover",
                   "Restore/Recharge benefit", "Room-rent waiver"],
        "exclusions": ["Pre-existing diseases during the waiting period",
                       "Cosmetic/aesthetic treatment", "Self-inflicted injury",
                       "Treatment outside India (unless opted)",
                       "Infertility/IVF (unless opted)", "War and nuclear perils"],
        "eligibility": "Entry age 18-65; children covered from 90 days on a "
                       "floater. Initial 30-day waiting period applies.",
        "collect": ["familySize", "preExistingConditions"],
    },
    "Life": {
        "summary": "A pure-protection term plan that pays a lump sum to your "
                   "nominee if you pass away during the policy term.",
        "covers": [
            "Death benefit (full sum assured to the nominee)",
            "Terminal illness benefit (early payout on terminal diagnosis)",
            "Optional accidental death and disability benefit",
            "Optional critical illness payout",
            "Optional waiver of future premiums on disability",
        ],
        "keyLimits": {
            "sumAssured": "Rs 25L to Rs 2 crore +",
            "policyTerm": "10 to 40 years",
            "maturity": "Nil for pure term (premiums returned in ROP variant)",
            "premiumTaxBenefit": "Section 80C",
            "payoutTax": "Tax-free u/s 10(10D)",
        },
        "addOns": ["Accidental Death Benefit", "Critical Illness",
                   "Waiver of Premium", "Permanent Disability", "Income Benefit"],
        "exclusions": ["Suicide within the first 12 months (premiums refunded)",
                       "Death from undisclosed pre-existing conditions",
                       "Fraud or misrepresentation in the proposal",
                       "Death while engaged in an illegal activity"],
        "eligibility": "Entry age 18-65; medical tests may be required based on "
                       "age and cover amount.",
        "collect": ["sumAssured", "policyTerm", "smoker", "nominee"],
    },
}


# The action names. The real tool name may be prefixed (e.g. "Auth_").
OPS = [
    "validateUser", "getPolicy", "getClaims", "getBenefits",
    "initiateClaim", "renewPolicy", "createCase", "onboardUser",
    "getProductCoverage",
]


def _op(tool_name: str) -> Optional[str]:
    """Resolve the action regardless of any tool/toolset prefix."""
    n = (tool_name or "").lower()
    for op in OPS:                       # exact or "<prefix>_<op>"
        if n == op.lower() or n.endswith(op.lower()):
            return op
    for op in OPS:                       # loose fallback
        if op.lower() in n:
            return op
    return None


def _phone(inp: dict[str, Any]) -> Optional[str]:
    """Pull the phone number out of the tool input, whatever key it uses."""
    for key in ("phone", "phoneNumber", "phone_number", "mobile", "customerPhone"):
        if inp.get(key):
            return str(inp[key]).strip()
    return None


def _product(inp: dict[str, Any]) -> Optional[str]:
    """Normalise a product/policy type string to Motor / Health / Life."""
    raw = (inp.get("productType") or inp.get("product") or inp.get("type")
           or inp.get("policyType") or "").strip().lower()
    if any(k in raw for k in ("motor", "vehicle", "car", "bike", "two-wheel")):
        return "Motor"
    if any(k in raw for k in ("health", "medical")):
        return "Health"
    if any(k in raw for k in ("life", "term")):
        return "Life"
    return None


def fake_tool_call(tool, input: dict[str, Any], callback_context) -> Optional[dict[str, Any]]:
    op = _op(getattr(tool, "name", "") or "")
    inp = input or {}
    phone = _phone(inp)
    cust = CUSTOMERS.get(phone) if phone else None

    # ── AUTHENTICATION (progressive: phone -> DOB -> security question) ──
    if op == "validateUser":
        if not cust:
            return {"valid": False, "stage": "lookup",
                    "message": "No customer found for that number. They may be a "
                               "new caller — offer onboarding."}
        dob = (inp.get("dob") or inp.get("dateOfBirth") or inp.get("date_of_birth") or "").strip()
        if not dob:
            return {"valid": False, "stage": "need_dob",
                    "message": "Phone matched. Ask for the date of birth on record "
                               "(format YYYY-MM-DD)."}
        if dob != cust["dob"]:
            return {"valid": False, "stage": "dob_mismatch",
                    "message": "That date of birth doesn't match our records."}
        answer = (inp.get("securityAnswer") or inp.get("answer")
                  or inp.get("security_answer") or "").strip()
        if not answer:
            # Phone + DOB are good; hand back the question to ask next.
            return {"valid": False, "stage": "need_security",
                    "securityQuestion": cust["security"]["question"],
                    "message": "Phone and DOB verified. Ask this security question, "
                               "then call validateUser again with securityAnswer."}
        if answer.lower() != cust["security"]["answer"].lower():
            return {"valid": False, "stage": "security_mismatch",
                    "message": "That answer doesn't match our records."}
        # Fully verified.
        return {
            "valid": True,
            "customerId": cust["customerId"],
            "name": cust["name"],
            "policyType": cust["policy"]["type"],
            "policyStatus": cust["policy"]["status"],
        }

    # ── READ operations ──
    if op == "getPolicy":
        if not cust:
            return {"found": False, "message": "No policy on record."}
        return {"found": True, "holder": cust["name"], **cust["policy"]}

    if op == "getClaims":
        if not cust:
            return {"found": False, "claims": []}
        return {"found": True, "count": len(cust["claims"]), "claims": cust["claims"]}

    if op == "getBenefits":
        if not cust:
            return {"found": False, "benefits": []}
        return {"found": True, "benefits": cust["benefits"]}

    if op == "getProductCoverage":
        ptype = _product(inp)
        if not ptype:
            return {"found": False, "available": list(PRODUCTS.keys()),
                    "message": "Which product would you like to hear about: "
                               "Motor, Health, or Life?"}
        return {"found": True, "product": ptype, **PRODUCTS[ptype]}

    # ── WRITE operations ──
    if op == "initiateClaim":
        if not cust:
            return {"success": False, "message": "Verify the customer before filing a claim."}
        reason = (inp.get("reason") or inp.get("claimReason")
                  or inp.get("description") or "Not specified")
        return {
            "success": True,
            "claimId": "CLM-2026-" + str(abs(hash(phone)) % 1000).zfill(3),
            "status": "Registered",
            "reason": reason,
            "message": f"Claim registered for {cust['name']} (reason: {reason}). "
                       f"You'll get an SMS update.",
        }

    if op == "renewPolicy":
        if not cust:
            return {"success": False, "message": "No policy found to renew."}
        return {
            "success": True,
            "policyId": cust["policy"]["policyId"],
            "previousRenewalDate": cust["policy"]["renewalDate"],
            "newRenewalDate": "2027-09-30",
            "amountDue": cust["policy"]["premium"],
            "message": "Renewal initiated. Payment link sent.",
        }

    if op == "createCase":  # escalation to a human agent — capture context
        summary = (inp.get("summary") or inp.get("context")
                   or inp.get("reason") or inp.get("issue") or "No summary provided")
        return {
            "success": True,
            "caseId": "CASE-2026-" + str(abs(hash(str(inp))) % 10000).zfill(4),
            "status": "Open",
            "summary": summary,
            "message": "Your case has been escalated to a human agent with the full "
                       "context of this conversation.",
        }

    if op == "onboardUser":  # a.k.a. createPolicy — new caller, no existing policy
        new_phone = phone or "0000000000"
        ptype = _product(inp) or "New"
        prefix = {"Motor": "MOTOR", "Health": "HEALTH", "Life": "LIFE"}.get(ptype, "NEW")
        return {
            "success": True,
            "customerId": "C0" + str(len(CUSTOMERS) + 1).zfill(2),
            "policyId": f"POL-{prefix}-" + str(abs(hash(new_phone)) % 1000).zfill(3),
            "policyType": ptype,
            "status": "Active",
            "message": f"Welcome aboard, {inp.get('name', 'new customer')}! "
                       f"Your {ptype} policy is now active.",
        }

    # Unknown tool -> let the real tool run
    return None
